LOBO 1 - corrector de textos que usam a "nova norma ortográfica" para
a norma ortográfica anterior. (simple spellcorrector in Python 3)

Copyright [2018] [J. Manuel Caeiro D. P.]

Licensed under the Academic Free License version 3.0 (the "License")*; you may not use this file except in compliance with the License.
You may obtain a copy of the License at
           https://opensource.org/licenses/AFL-3.0

---
1. Os seguintes ficheiros são indispensáveis para correcta apresentação e execução do programa:
lobo_1.exe (executável),
wordlistao.md (texto),
wordlistcr.md (texto),
OrderChristCross-100px-logo1.png (imagem)

2. Faça click sobre o ficheiro executável (lobo_1) com o botão direito do rato e se aparecer no menu a opção "executar" (ou "execute") seleccione-a e o programa iniciar-se-á. (Em alguns ambientes de janelas - como o Cinnamon, por exemplo - é possível iniciar o programa fazendo duplo click sobre o ficheiro executável.)
Siga as indicações em "COMO USAR".
	- Se o programa não iniciar com os procedimentos descritos acima, abra a
	pasta Lobo_1, faça clik	com o botão direito do rato dentro da janela e
	escolha a opção "Abrir	Terminal Aqui" (ou "Open Terminal Here").
	- Escreva o seguinte na linha de comando: ./lobo_1
	- Prima a tecla "return" (ou "enter").
	
	nota: para poder fechar a janela do terminal sem fechar também as janelas
	do LOBO 1 experimente escrever: ./lobo_1 & disown
	
3. Logo após a interface gráfica ter fechado deverá aparecer um novo ficheiro com o texto corrigido dentro da sua pasta "LOBO_1".

Nota 1: Se não aparecer um novo ficheiro ou se o novo ficheiro estiver vazio quererá dizer que o LOBO falhou.

Nota 2: Como qualquer outra tradução automática mecânica, esta precisará de revisão para detectar correcções inadequadas ao contexto e eventuais omissões.


Limitações desta versão inicial do programa:

- Abre e processa apenas um ficheiro de cada vez.
- Lê, modifica e grava somente o texto dos documentos originais, não os reconstitui.
- Não lê alguns 'pdf' resultantes de conversões a partir de outros formatos de texto.
 - Não tem capacidade para processar correctamente páginas 'web', só documentos de texto com extensão 'html'.
    
(Para corrigir textos em páginas 'web' instale as extensões existentes para o Chrome e o Firefox.)

---
*Why is LOBO 1 licensed under the Academic Free License version 3.0:
https://www.openfoundry.org/en/licenses/753-academic-free-license-version-30-afl
